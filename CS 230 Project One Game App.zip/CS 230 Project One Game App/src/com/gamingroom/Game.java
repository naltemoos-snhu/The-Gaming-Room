package com.gamingroom;

//library imports to make arrays and list work
import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
	
	// lists the active teams
	private static List<Team> teams = new ArrayList<Team>();
	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	// new team instance
	public Team addTeam(String name) {
		// base instance
		Team team = null;
		
		// team iterator to check for duplicate names
		for (int i = 0; i < teams.size() - 1; i++) {
			if (teams.get(i).getName() == name) {
				team = teams.get(i);
			}
		}
		
		// new instance if not found
		if (team == null) {
			GameService service = GameService.getInstance();
			
			// reference from instance in game service and new team id
			team = new Team(service.getNextPlayerId(), name);
			teams.add(team);
		}
		
		// returns the game instance to the user
		return team;
	}
	public String toString() {
		return "Player [id=" + id + ", name=" + name + "]";
	}
}
