package com.gamingroom;

// library imports to make arrays and list work
import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{

	// list the active teams
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	// new player instance
	public Player addPlayer(String name) {
		// base instance
		Player player = null;
		
		// player iterator to check for duplicate names
		for (int i = 0; i < players.size() - 1; i++) {
			if (players.get(i).getName() == name) {
				player = players.get(i);
			}
		}
		
		// new instance if not found
		if (player == null) {
			GameService service = GameService.getInstance();
			
			
		}
		
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
